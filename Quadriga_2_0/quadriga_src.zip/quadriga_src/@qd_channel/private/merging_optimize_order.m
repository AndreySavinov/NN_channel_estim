function [ output_args ] = merging_optimize_order( input_args )
%MERGING_OPTIMIZE_ORDER Summary of this function goes here
%   Detailed explanation goes here


end

